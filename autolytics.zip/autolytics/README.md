# autolytics

Point it at a table of data. It loads it, cleans it, analyses it and charts it, from a **CLI** or a **web dashboard**. No configuration needed.

```bash
pip install -e ".[dashboard]"

autolytics demo --open                  # try it on a messy synthetic health dataset
autolytics run clinic_visits.xlsx --open
autolytics dashboard                    # web UI: upload a file in the browser
```

## What it does

| Stage | What happens |
|---|---|
| **Ingest** | CSV, TSV, Excel, JSON, JSON Lines, Parquet, Feather, SQLite, XML, HTML tables. Encoding and delimiter are sniffed. Unknown extensions are tried as delimited text. |
| **Clean** | snake_case names, trimmed text, `N/A`/`-`/`null` become missing, `"72 kg"` and `"MK 12,300"` become numbers, mixed date formats are parsed (day-first detected), yes/no become booleans, spellings that differ only by case are merged, duplicates removed, mostly-empty columns dropped, missing values filled by column type. **Outliers are flagged, never silently removed.** Every change goes into a cleaning log. |
| **Analyse** | Type-aware: distributions, skew, correlations (Pearson and Spearman), group differences (Kruskal-Wallis), category associations (Cramér's V), time trends, and an optional ranking against a `--target` column. Results become plain-English insights. |
| **Visualise** | Histograms and box plots, ranked bars, correlation heatmap, scatter with fit line, group box plots, trend lines. Colour-blind-safe palette, light and dark. |
| **Report** | One self-contained HTML file (works offline, theme toggle), plus a cleaned CSV and a JSON cleaning log. |

## Handling health and other personal data

Records often include names, phone numbers or national IDs. autolytics detects likely identifier columns and warns you. Before sharing any output:

```bash
autolytics run records.csv --anonymize hash   # stable pseudonyms
autolytics run records.csv --anonymize drop   # remove the columns
```

Never commit real records to Git. `data/` and the output folders are in `.gitignore`. Statistical findings on small samples (a warning appears under 200 rows) are leads to investigate, not conclusions.

## CLI

```
autolytics run FILE [-o DIR] [-t TARGET] [-c config.yaml] [--sheet NAME] [--anonymize hash|drop]
                    [--outliers iqr|zscore|none] [--clip-outliers] [--no-report] [--open] [--dark]
autolytics profile FILE     # types, missing values and outliers in the terminal
autolytics dashboard [FILE] # web dashboard
autolytics demo             # synthetic 168-row health dataset
autolytics formats
```

All options live in `autolytics/config.py`; see `examples/config.yaml`.

## As a library

```python
import autolytics
res = autolytics.run("visits.csv", out_dir="out", config=autolytics.Config(target="systolic_bp"))
res.df                  # cleaned DataFrame
res.analysis.insights   # list of {level, text}
res.cleaned.log         # every cleaning step
```

## Project layout

```
autolytics/  ingest.py  clean.py  privacy.py  analyze.py  visualize.py  report.py
             pipeline.py  cli.py  dashboard.py  config.py  sample.py
tests/       pytest suite (formats, cleaning, privacy, CLI)
```

Run the tests with `pytest`. Ideas for next steps: more chart types, a regression/baseline-model stage, a plugin hook for custom cleaning rules.

MIT licensed.

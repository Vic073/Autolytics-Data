import json

import pandas as pd
import pytest
from typer.testing import CliRunner

from autolytics import Config, clean, load_data, run
from autolytics.cli import app
from autolytics.privacy import detect_pii
from autolytics.sample import make_messy_health_data


@pytest.fixture(scope="module")
def messy():
    return make_messy_health_data()


@pytest.fixture(scope="module")
def result(messy, tmp_path_factory):
    return run(messy, tmp_path_factory.mktemp("out"))


def test_cleaning_types_and_rows(result):
    s = result.cleaned.schema
    assert result.cleaned.rows_in == 168 and result.cleaned.rows_out == 164
    assert s["weight"] == "numeric"            # "71.2 kg" strings parsed
    assert s["treatment_cost"] == "numeric"    # "MK 12,300" parsed
    assert s["visit_date"] == "datetime"
    assert s["patient_id"] == "id"
    assert "notes" not in result.cleaned.df and "referral" not in result.cleaned.df   # mostly empty -> dropped


def test_case_variants_merged(result):
    vals = set(result.cleaned.df["sex"].unique())
    assert "Male" in vals and "male" not in vals and "MALE" not in vals
    assert any(e["step"] == "categories" for e in result.cleaned.log)


def test_dates_are_day_first(result):
    d = result.cleaned.df["visit_date"]
    assert d.min().year == 2025 and d.max() <= pd.Timestamp("2026-01-01")
    assert d.dt.month.nunique() > 6          # month/day not swapped into a narrow range


def test_outliers_flagged_not_removed(result):
    assert result.cleaned.df["systolic_bp"].max() >= 300
    assert result.cleaned.outliers["age_yrs"]["count"] >= 1


def test_outputs_written(result):
    assert result.outputs["report"].exists() and result.outputs["report"].stat().st_size > 100_000
    log = json.loads(result.outputs["log_json"].read_text())
    assert log["rows_in"] == 168 and log["log"]


def test_insights_present(result):
    assert any("correlated" in i["text"] for i in result.analysis.insights)


@pytest.mark.parametrize("ext", ["csv", "tsv", "xlsx", "json", "jsonl", "parquet", "sqlite"])
def test_formats_roundtrip(tmp_path, ext):
    df = pd.DataFrame({"a b": range(30), "Group": ["x", "y", "z"] * 10, "val": [i * 1.5 for i in range(30)]})
    p = tmp_path / f"d.{ext}"
    {"csv": lambda: df.to_csv(p, index=False), "tsv": lambda: df.to_csv(p, sep="\t", index=False),
     "xlsx": lambda: df.to_excel(p, index=False), "json": lambda: df.to_json(p, orient="records"),
     "jsonl": lambda: df.to_json(p, orient="records", lines=True), "parquet": lambda: df.to_parquet(p),
     "sqlite": lambda: __import__("sqlite3").connect(p).__enter__() and df.to_sql(
         "t", __import__("sqlite3").connect(p), index=False)}[ext]()
    loaded, info = load_data(p)
    assert len(loaded) == 30 and info.fmt


def test_semicolon_and_latin1_csv(tmp_path):
    p = tmp_path / "x.csv"
    p.write_bytes("nom;âge;ville\nJosé;30;Zomba\nZoë;41;Blantyre\n".encode("cp1252"))
    df, info = load_data(p)
    assert list(df.columns) == ["nom", "âge", "ville"] and info.delimiter == ";"


def test_any_data_does_not_crash():
    # no numeric columns, one column, all-text, constant column, tiny table
    for df in [pd.DataFrame({"a": list("abcabc")}),
               pd.DataFrame({"a": [1] * 10, "b": list("xyxyxyxyxy")}),
               pd.DataFrame({"t": ["hello world"] * 3, "u": ["foo", "bar", "baz"]}),
               pd.DataFrame({"n": range(5)})]:
        r = run(df)
        assert r.analysis.insights


def test_pii_detection_and_anonymise(tmp_path):
    df = pd.DataFrame({"Full Name": [f"Person {i}" for i in range(20)], "phone": ["+265 999 123 456"] * 20,
                       "age": range(20, 40)})
    assert set(detect_pii(df)) == {"Full Name", "phone"}
    r = run(df, tmp_path, Config(anonymize="drop"))
    assert "full_name" not in r.cleaned.df and "phone" not in r.cleaned.df
    r2 = run(df, tmp_path, Config(anonymize="hash"))
    assert r2.cleaned.df["full_name"].astype(str).str.startswith("anon_").all() or "full_name" in r2.cleaned.df


def test_target_ranking(messy):
    r = run(messy, config=Config(target="systolic_bp"))
    assert r.analysis.target_ranking[0]["feature"] in {"diastolic_bp", "age_yrs"}


def test_unknown_config_key_rejected():
    with pytest.raises(ValueError):
        Config.load(None, nonsense=1)


def test_cli(tmp_path):
    runner = CliRunner()
    src = tmp_path / "h.csv"
    make_messy_health_data().to_csv(src, index=False)
    r = runner.invoke(app, ["run", str(src), "-o", str(tmp_path / "o"), "--anonymize", "hash"])
    assert r.exit_code == 0, r.output
    assert (tmp_path / "o" / "h_report.html").exists()
    r = runner.invoke(app, ["profile", str(src)])
    assert r.exit_code == 0 and "systolic_bp" in r.output
    r = runner.invoke(app, ["run", str(tmp_path / "missing.csv")])
    assert r.exit_code == 1

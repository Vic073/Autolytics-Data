"""Load almost any tabular data source into a pandas DataFrame."""
from __future__ import annotations

import io
import json
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

ENCODINGS = ("utf-8-sig", "utf-8", "cp1252", "latin-1")
SUPPORTED = (
    ".csv .tsv .txt .dat .xlsx .xlsm .xls .json .jsonl .ndjson "
    ".parquet .feather .sqlite .sqlite3 .db .xml .html"
).split()


@dataclass
class LoadInfo:
    source: str
    fmt: str
    encoding: str | None = None
    delimiter: str | None = None
    sheet: str | None = None
    notes: list[str] = field(default_factory=list)


def _read_text_table(path: Path) -> tuple[pd.DataFrame, LoadInfo]:
    info = LoadInfo(str(path), "delimited text")
    last_err: Exception | None = None
    for enc in ENCODINGS:
        try:
            raw = path.read_text(encoding=enc)
        except UnicodeDecodeError as e:
            last_err = e
            continue
        info.encoding = enc
        sample = raw[:20000]
        sep = None
        if path.suffix.lower() == ".tsv":
            sep = "\t"
        else:
            import csv

            try:
                sep = csv.Sniffer().sniff(sample, delimiters=",;\t|:").delimiter
            except csv.Error:
                sep = ","
        info.delimiter = sep
        df = pd.read_csv(
            io.StringIO(raw), sep=sep, engine="python",
            skip_blank_lines=True, on_bad_lines="warn",
        )
        # One column holding the delimiter means the sniff was wrong; retry on commas.
        if df.shape[1] == 1 and sep != "," and "," in sample.splitlines()[0]:
            df = pd.read_csv(io.StringIO(raw), sep=",", engine="python")
            info.delimiter = ","
        return df, info
    raise ValueError(f"Could not decode {path.name}: {last_err}")


def _flatten_json(obj) -> pd.DataFrame:
    if isinstance(obj, list):
        return pd.json_normalize(obj)
    if isinstance(obj, dict):
        # Prefer the first value that is a list of records (common API shape).
        for v in obj.values():
            if isinstance(v, list) and v and isinstance(v[0], dict):
                return pd.json_normalize(v)
        # Dict of equal-length lists -> columns; otherwise a single record.
        try:
            return pd.DataFrame(obj)
        except ValueError:
            return pd.json_normalize(obj)
    raise ValueError("JSON must be a list of records or an object containing one.")


def _read_sqlite(path: Path, table: str | int | None) -> tuple[pd.DataFrame, LoadInfo]:
    info = LoadInfo(str(path), "sqlite")
    with sqlite3.connect(path) as con:
        tables = [r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table','view') "
            "AND name NOT LIKE 'sqlite_%'")]
        if not tables:
            raise ValueError("SQLite database contains no tables.")
        name = tables[table] if isinstance(table, int) else (table or tables[0])
        if name not in tables:
            raise ValueError(f"Table {name!r} not found. Available: {tables}")
        df = pd.read_sql_query(f'SELECT * FROM "{name}"', con)
    info.sheet = name
    if len(tables) > 1:
        info.notes.append(f"Database has {len(tables)} tables; used {name!r}. Others: {tables}")
    return df, info


def _read_excel(path: Path, sheet: str | int | None) -> tuple[pd.DataFrame, LoadInfo]:
    info = LoadInfo(str(path), "excel")
    xl = pd.ExcelFile(path)
    names = xl.sheet_names
    chosen = names[sheet] if isinstance(sheet, int) else (sheet or names[0])
    df = xl.parse(chosen)
    info.sheet = str(chosen)
    if len(names) > 1:
        info.notes.append(f"Workbook has {len(names)} sheets; used {chosen!r}. Others: {names}")
    return df, info


def _drop_empty_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Remove fully empty rows/columns and 'Unnamed: n' columns with no data."""
    df = df.dropna(how="all").dropna(axis=1, how="all")
    return df.reset_index(drop=True)


def load_data(source, sheet: str | int | None = None) -> tuple[pd.DataFrame, LoadInfo]:
    """Load a file path or an in-memory DataFrame. Returns (DataFrame, LoadInfo)."""
    if isinstance(source, pd.DataFrame):
        return _drop_empty_frame(source.copy()), LoadInfo("<DataFrame>", "dataframe")

    path = Path(source)
    if not path.exists():
        raise FileNotFoundError(f"No such file: {path}")
    ext = path.suffix.lower()

    if ext in {".csv", ".tsv", ".txt", ".dat"}:
        df, info = _read_text_table(path)
    elif ext in {".xlsx", ".xlsm", ".xls"}:
        df, info = _read_excel(path, sheet)
    elif ext in {".json"}:
        info = LoadInfo(str(path), "json")
        df = _flatten_json(json.loads(path.read_text(encoding="utf-8-sig")))
    elif ext in {".jsonl", ".ndjson"}:
        info = LoadInfo(str(path), "json lines")
        df = pd.read_json(path, lines=True)
    elif ext == ".parquet":
        info = LoadInfo(str(path), "parquet")
        df = pd.read_parquet(path)
    elif ext == ".feather":
        info = LoadInfo(str(path), "feather")
        df = pd.read_feather(path)
    elif ext in {".sqlite", ".sqlite3", ".db"}:
        df, info = _read_sqlite(path, sheet)
    elif ext == ".xml":
        info = LoadInfo(str(path), "xml")
        df = pd.read_xml(path)
    elif ext == ".html":
        info = LoadInfo(str(path), "html table")
        tables = pd.read_html(path)
        df = tables[0]
        if len(tables) > 1:
            info.notes.append(f"Page has {len(tables)} tables; used the first.")
    else:
        # Unknown extension: try it as delimited text before giving up.
        try:
            df, info = _read_text_table(path)
            info.notes.append(f"Unrecognised extension {ext!r}; parsed as delimited text.")
        except Exception as e:
            raise ValueError(
                f"Unsupported file type {ext!r}. Supported: {', '.join(SUPPORTED)}"
            ) from e

    df = _drop_empty_frame(df)
    if df.empty:
        raise ValueError("The file loaded but contains no data rows.")
    return df, info

"""Streamlit dashboard. Launch with `autolytics dashboard` (or `streamlit run autolytics/dashboard.py`)."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from autolytics import Config, run
from autolytics.clean import BOOLEAN, CATEGORICAL, DATETIME, NUMERIC
from autolytics.ingest import SUPPORTED
from autolytics.report import SECTIONS
from autolytics.sample import make_messy_health_data
from autolytics.visualize import THEMES, _base, build_charts

st.set_page_config(page_title="autolytics", page_icon="📊", layout="wide")
CLI_PATH = sys.argv[1] if len(sys.argv) > 1 else None


def _theme() -> str:
    try:
        return "dark" if st.context.theme.type == "dark" else "light"
    except Exception:
        return "light"


@st.cache_data(show_spinner="Running pipeline...")
def _run(data: bytes | None, name: str, path: str | None, cfg_json: str):
    cfg = Config(**json.loads(cfg_json))
    with tempfile.TemporaryDirectory() as d:
        if data is not None:
            src = Path(d) / Path(name).name
            src.write_bytes(data)
        else:
            src = Path(path)  # type: ignore[arg-type]
        res = run(src, Path(d) / "out", cfg, report=True, export=True)
        return {
            "res": res,
            "report": res.outputs["report"].read_bytes(),
            "csv": res.outputs["clean_csv"].read_bytes(),
            "log": res.outputs["log_json"].read_bytes(),
        }


# ---------------- sidebar ----------------
st.sidebar.title("📊 autolytics")
st.sidebar.caption("Upload any table. Get it cleaned, analysed and charted.")
source = st.sidebar.radio("Data source", ["Upload a file", "Sample health data"] + (["Preloaded file"] if CLI_PATH else []),
                          index=2 if CLI_PATH else 0)
data = name = path = None
if source == "Upload a file":
    up = st.sidebar.file_uploader("File", type=[s.lstrip(".") for s in SUPPORTED])
    if up:
        data, name = up.getvalue(), up.name
elif source == "Sample health data":
    name = "sample_health_records.csv"
    data = make_messy_health_data().to_csv(index=False).encode()
else:
    path, name = CLI_PATH, Path(CLI_PATH).name

with st.sidebar.expander("Settings", expanded=False):
    title = st.text_input("Report title", f"Analysis of {name}" if name else "Data Analysis Report")
    outlier_method = st.selectbox("Outlier detection", ["iqr", "zscore", "none"])
    numeric_impute = st.selectbox("Fill missing numbers with", ["median", "mean", "none"])
    drop_thr = st.slider("Drop columns missing more than", 0.1, 1.0, 0.6, 0.05)
    anonymize = st.selectbox("Personal identifiers", ["none", "hash", "drop"],
                             help="Applies to columns that look like names, phones, emails, IDs.")
    sheet = st.text_input("Excel sheet / SQLite table (blank = first)")

if data is None and path is None:
    st.title("autolytics")
    st.write("Upload a CSV, Excel, JSON, Parquet, SQLite, XML or HTML table in the sidebar, "
             "or pick the sample health data to see what it does.")
    st.stop()

# Target needs a first pass for the column list.
base_cfg = dict(title=title, outlier_method=outlier_method, numeric_impute=numeric_impute,
                missing_drop_col_threshold=drop_thr, anonymize=anonymize,
                sheet=(int(sheet) if sheet.isdigit() else sheet) if sheet else None)
try:
    first = _run(data, name, path, json.dumps(base_cfg))
except Exception as e:  # surface parse problems nicely instead of a stack trace
    st.error(f"Could not process this file: {e}")
    st.stop()
cols = list(first["res"].cleaned.df.columns)
target = st.sidebar.selectbox("Focus on a target column (optional)", [None] + cols)
out = first if not target else _run(data, name, path, json.dumps({**base_cfg, "target": target}))
res = out["res"]
A, C, df = res.analysis, res.cleaned, res.cleaned.df
theme = _theme()
T = THEMES[theme]

# ---------------- header ----------------
st.title(title)
st.caption(f"{name} · {res.info.fmt}" + (f" · {res.info.encoding}" if res.info.encoding else ""))
for note in res.info.notes:
    st.info(note)
if res.pii and anonymize == "none":
    st.warning(f"Possible personal identifiers in {list(res.pii)}. Set 'Personal identifiers' to hash or drop "
               "in Settings before sharing downloads.")

o = A.overview
k = st.columns(6)
k[0].metric("Rows", f"{o['rows']:,}", f"{o['rows'] - o['rows_in']:+d} cleaned" if o["rows"] != o["rows_in"] else None)
k[1].metric("Columns", o["columns"])
k[2].metric("Numeric", o["kinds"].get("numeric", 0))
k[3].metric("Categorical", o["kinds"].get("categorical", 0) + o["kinds"].get("boolean", 0))
k[4].metric("Missing cells (raw)", f"{o['missing_cells_before']:,}")
k[5].metric("Outliers flagged", f"{o['total_outliers']:,}")

tabs = st.tabs(["Insights", "Charts", "Build a chart", "Data", "Cleaning log", "Download"])

# ---------------- insights ----------------
with tabs[0]:
    for i in A.insights:
        {"info": st.info, "notable": st.success, "warning": st.warning}[i["level"]](i["text"], icon=None)
    if A.target_ranking:
        st.subheader(f"What relates most to {target}")
        st.dataframe(pd.DataFrame(A.target_ranking), hide_index=True, width="stretch")

# ---------------- chart gallery ----------------
with tabs[1]:
    charts = build_charts(C, A, res.config, theme)
    present = [(k_, n) for k_, n, _ in SECTIONS if any(c.section == k_ for c in charts)]
    pick = st.multiselect("Sections", [n for _, n in present], default=[n for _, n in present])
    for key, nm in present:
        if nm not in pick:
            continue
        st.subheader(nm)
        items = [c for c in charts if c.section == key]
        for i in range(0, len(items), 2):
            row = st.columns(2)
            for col, c in zip(row, items[i:i + 2]):
                with col:
                    st.markdown(f"**{c.title}**")
                    st.caption(c.caption)
                    st.plotly_chart(c.fig, width="stretch", key=c.id,
                                    config={"displaylogo": False})

# ---------------- chart builder ----------------
with tabs[2]:
    nums = [c for c, kd in C.schema.items() if kd == NUMERIC]
    cats = [c for c, kd in C.schema.items() if kd in (CATEGORICAL, BOOLEAN)]
    dates = [c for c, kd in C.schema.items() if kd == DATETIME]
    kind = st.radio("Chart", ["Scatter", "Bar (average by group)", "Histogram", "Line over time"], horizontal=True)
    fig = None
    if kind == "Scatter" and len(nums) >= 2:
        a, b = st.columns(2)
        x = a.selectbox("X", nums, 0)
        y = b.selectbox("Y", nums, 1)
        by = st.selectbox("Colour by (optional)", [None] + [c for c in cats if df[c].nunique() <= 8])
        fig = go.Figure()
        groups = [(None, df)] if not by else list(df.groupby(by))
        for i, (g, d) in enumerate(groups):
            fig.add_trace(go.Scatter(x=d[x], y=d[y], mode="markers", name=str(g) if by else "Rows",
                                     marker=dict(color=T["series"][i], size=8, opacity=.8,
                                                 line=dict(color=T["surface"], width=1.5))))
        _base(fig, T, height=460, legend=bool(by), x=x, y=y)
    elif kind.startswith("Bar") and nums and cats:
        a, b = st.columns(2)
        g = a.selectbox("Group", cats)
        m = b.selectbox("Measure", nums)
        agg = df.groupby(g)[m].mean().sort_values()
        fig = go.Figure(go.Bar(y=agg.index.astype(str), x=agg.values, orientation="h",
                               marker=dict(color=T["series"][0]), marker_cornerradius=4))
        _base(fig, T, height=max(300, 36 * len(agg) + 100), x=f"Mean {m}")
        fig.update_yaxes(showgrid=False, automargin=True)
    elif kind == "Histogram" and nums:
        m = st.selectbox("Measure", nums)
        by = st.selectbox("Split by (optional)", [None] + [c for c in cats if df[c].nunique() <= 4])
        fig = go.Figure()
        for i, (g, d) in enumerate([(None, df)] if not by else list(df.groupby(by))):
            fig.add_trace(go.Histogram(x=d[m], name=str(g) if by else m, opacity=.75 if by else 1,
                                       marker=dict(color=T["series"][i], line=dict(color=T["surface"], width=1.5))))
        fig.update_layout(barmode="overlay")
        _base(fig, T, height=420, legend=bool(by), x=m, y="Count")
    elif kind.startswith("Line") and dates and nums:
        a, b, c3 = st.columns(3)
        dcol = a.selectbox("Date", dates)
        m = b.selectbox("Measure", nums)
        fr = c3.selectbox("Period", ["W", "ME", "D", "YE"], 1)
        s = df[[dcol, m]].dropna().set_index(dcol)[m].resample(fr).mean()
        fig = go.Figure(go.Scatter(x=s.index, y=s.values, mode="lines+markers",
                                   line=dict(color=T["series"][0], width=2), marker=dict(size=8)))
        _base(fig, T, height=420, y=f"Mean {m}")
    if fig is None:
        st.info("This chart needs columns the data doesn't have (for example two numeric columns, or a date).")
    else:
        st.plotly_chart(fig, width="stretch", key="builder")

# ---------------- data ----------------
with tabs[3]:
    st.caption("Cleaned data. Column types detected:")
    st.dataframe(pd.DataFrame({"column": list(C.schema), "type": list(C.schema.values()),
                               "missing (raw)": [C.missing_before.get(c, 0) for c in C.schema],
                               "outliers": [C.outliers.get(c, {}).get("count", 0) for c in C.schema]}),
                 hide_index=True, width="stretch")
    flagged = sorted({r for v in C.outliers.values() for r in v["rows"]})
    only = st.toggle(f"Show only rows with flagged outliers ({len(flagged)})") if flagged else False
    st.dataframe(df.loc[flagged] if only else df, width="stretch")

# ---------------- log ----------------
with tabs[4]:
    st.dataframe(pd.DataFrame(C.log), hide_index=True, width="stretch")

# ---------------- downloads ----------------
with tabs[5]:
    stem = Path(name).stem
    c1, c2, c3 = st.columns(3)
    c1.download_button("Cleaned data (CSV)", out["csv"], f"{stem}_clean.csv", "text/csv")
    c2.download_button("Interactive report (HTML)", out["report"], f"{stem}_report.html", "text/html")
    c3.download_button("Cleaning log (JSON)", out["log"], f"{stem}_cleaning_log.json", "application/json")
    if res.pii and anonymize == "none":
        st.warning("Downloads still contain possible personal identifiers.")

"""Generate a deliberately messy, synthetic 168-row health-records dataset for demos and tests.

All data is fabricated. Messiness included: mixed date formats, placeholder text for missing,
units glued to numbers, inconsistent category spelling, duplicates, stray whitespace, outliers.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def make_messy_health_data(n: int = 168, seed: int = 7) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    base = n - 4  # last 4 rows are duplicates
    age = np.clip(rng.normal(41, 16, base), 1, 90).round().astype(int)
    sex = rng.choice(["Male", "Female"], base)
    weight = np.clip(rng.normal(66, 13, base) + (age > 30) * 4, 30, 140).round(1)
    height = np.clip(rng.normal(166, 9, base), 120, 200).round(0)
    bmi = (weight / (height / 100) ** 2).round(1)
    sbp = (100 + 0.55 * age + 0.35 * (bmi - 22) * 2 + rng.normal(0, 9, base)).round()
    dbp = (sbp * 0.58 + rng.normal(8, 5, base)).round()
    glucose = np.clip(rng.normal(5.4, 1.1, base) + 0.03 * (bmi - 22), 3.2, 16).round(1)
    hr = np.clip(rng.normal(76, 11, base), 45, 130).round()
    temp = np.clip(rng.normal(36.8, 0.5, base), 35, 41).round(1)
    diagnosis = rng.choice(["Malaria", "Hypertension", "Diabetes", "Respiratory infection", "Healthy check-up",
                            "Typhoid", "Anaemia"], base, p=[.27, .18, .09, .2, .13, .07, .06])
    smoker = rng.choice(["Yes", "No"], base, p=[.18, .82])
    district = rng.choice(["Zomba", "Blantyre", "Lilongwe", "Mzuzu", "Machinga"], base)
    visit = pd.to_datetime("2025-01-06") + pd.to_timedelta(rng.integers(0, 300, base), unit="D")
    cost = (rng.gamma(3.0, 6000, base) + 4000).round(-2)

    df = pd.DataFrame({
        "Patient ID": [f"P{1000 + i}" for i in range(base)],
        "Visit Date": visit, "Age (yrs)": age, "Sex": sex, "Weight": weight, "Height cm": height,
        "BMI": bmi, "Systolic BP": sbp, "Diastolic BP": dbp, "Blood Glucose": glucose,
        "Heart Rate": hr, "Temp C": temp, "Diagnosis": diagnosis, "Smoker": smoker,
        "District": district, "Treatment Cost": cost,
    }).astype(object)

    # --- inject mess ---
    fmts = ["%d/%m/%Y", "%Y-%m-%d", "%d %b %Y"]
    df["Visit Date"] = [d.strftime(fmts[i % 3]) for i, d in enumerate(visit)]
    df["Sex"] = [rng.choice([s, s.lower(), s.upper(), s[0], " " + s]) if rng.random() < .25 else s for s in sex]
    df["Treatment Cost"] = [f"MK {int(c):,}" if i % 2 else int(c) for i, c in enumerate(cost)]
    df["Weight"] = [f"{w} kg" if i % 5 == 0 else w for i, w in enumerate(weight)]
    for col, rate, tok in [("Blood Glucose", .12, "N/A"), ("Heart Rate", .07, "-"), ("BMI", .05, None),
                           ("Smoker", .08, "unknown"), ("Systolic BP", .04, "null"), ("Temp C", .06, "")]:
        for i in rng.choice(base, int(base * rate), replace=False):
            df.at[i, col] = tok
    df.at[5, "Systolic BP"] = 300          # impossible-ish outlier
    df.at[17, "Blood Glucose"] = 41.0      # outlier
    df.at[30, "Age (yrs)"] = 134           # data-entry error
    df["Notes"] = [None] * base            # entirely empty column
    df["Referral"] = [rng.choice(["yes", "no"]) if rng.random() < .35 else None for _ in range(base)]
    df = pd.concat([df, df.iloc[[3, 20, 45, 80]]], ignore_index=True)   # duplicates
    return df

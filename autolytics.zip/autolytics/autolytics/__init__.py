"""autolytics: point it at data, get a cleaned dataset, analysis and an interactive report."""
from .analyze import Analysis, analyze
from .clean import CleanResult, clean
from .config import Config
from .ingest import load_data
from .pipeline import PipelineResult, run
from .visualize import build_charts

__version__ = "0.1.0"
__all__ = ["Config", "run", "load_data", "clean", "analyze", "build_charts",
           "PipelineResult", "CleanResult", "Analysis"]

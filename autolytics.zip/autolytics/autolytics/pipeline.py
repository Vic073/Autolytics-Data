"""End-to-end orchestration: load -> clean -> analyse -> visualise -> report."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from .analyze import Analysis, analyze
from .clean import CleanResult, clean
from .config import Config
from .ingest import LoadInfo, load_data
from .privacy import anonymize, detect_pii
from .report import render_report
from .visualize import Chart, build_charts


@dataclass
class PipelineResult:
    raw: pd.DataFrame
    info: LoadInfo
    cleaned: CleanResult
    analysis: Analysis
    charts: list[Chart]
    config: Config
    outputs: dict[str, Path]
    pii: dict[str, str] | None = None

    @property
    def df(self) -> pd.DataFrame:
        return self.cleaned.df


def run(source, out_dir: str | Path | None = None, config: Config | None = None,
        report: bool = True, export: bool = True) -> PipelineResult:
    """Run the whole pipeline. `source` is a file path or a DataFrame."""
    cfg = config or Config()
    raw, info = load_data(source, cfg.sheet)
    pii = detect_pii(raw)
    for c in cfg.anonymize_columns or []:
        if c in raw.columns:
            pii.setdefault(c, "listed in anonymize_columns")
    if cfg.anonymize != "none" and pii:
        raw = anonymize(raw, list(pii), cfg.anonymize)
    cleaned = clean(raw, cfg)
    if pii:
        verb = {"none": "detected, left as is (use --anonymize hash|drop before sharing outputs)",
                "hash": "replaced with irreversible hashes", "drop": "dropped"}[cfg.anonymize]
        for c, why in pii.items():
            cleaned.add("privacy", f"Possible personal identifier ({why}): {verb}", c)
    an = analyze(cleaned, cfg)
    if pii and cfg.anonymize == "none":
        an.insights.insert(1, {"level": "warning", "text":
            f"Possible personal identifiers found in {', '.join(map(repr, pii))}. Anonymise "
            "(--anonymize hash or drop) before sharing the cleaned CSV or report."})
    light = build_charts(cleaned, an, cfg, "light")
    outputs: dict[str, Path] = {}

    if out_dir is not None and (report or export):
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        stem = Path(info.source).stem if info.source != "<DataFrame>" else "data"
        if export:
            outputs["clean_csv"] = out / f"{stem}_clean.csv"
            cleaned.df.to_csv(outputs["clean_csv"], index=False)
            outputs["log_json"] = out / f"{stem}_cleaning_log.json"
            outputs["log_json"].write_text(json.dumps({
                "source": info.source, "format": info.fmt, "encoding": info.encoding,
                "delimiter": info.delimiter, "notes": info.notes,
                "rows_in": cleaned.rows_in, "rows_out": cleaned.rows_out,
                "schema": cleaned.schema, "renamed_columns": cleaned.renamed,
                "dropped_columns": cleaned.dropped_columns,
                "outliers": {k: {kk: vv for kk, vv in v.items() if kk != "rows"}
                             for k, v in cleaned.outliers.items()},
                "log": cleaned.log, "insights": an.insights, "config": cfg.to_dict(),
            }, indent=2, default=str), encoding="utf-8")
        if report:
            dark = build_charts(cleaned, an, cfg, "dark")
            outputs["report"] = render_report(
                cleaned, an, light, dark, cfg, Path(info.source).name if info.source != "<DataFrame>"
                else "DataFrame", out / f"{stem}_report.html")
    return PipelineResult(raw, info, cleaned, an, light, cfg, outputs, pii)

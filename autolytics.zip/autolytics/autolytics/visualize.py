"""Chart selection and rendering. Chart form follows the data's job:

magnitude/shape -> histogram + box, identity -> sorted bars, polarity -> diverging heatmap,
change over time -> line, relationship -> scatter. Colours come from a validated palette
(CVD-safe categorical order; single-hue sequential; blue<->red diverging with grey midpoint).
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from .analyze import Analysis
from .clean import BOOLEAN, CATEGORICAL, DATETIME, NUMERIC, CleanResult
from .config import Config

THEMES = {
    "light": dict(
        surface="#fcfcfb", text="#0b0b0b", text2="#52514e", muted="#898781",
        grid="#e1e0d9", axis="#c3c2b7", mid="#f0efec",
        series=["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"],
        pos="#2a78d6", neg="#e34948",
        seq=["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"],
    ),
    "dark": dict(
        surface="#1a1a19", text="#f0efec", text2="#c3c2b7", muted="#898781",
        grid="#2c2c2a", axis="#383835", mid="#383835",
        series=["#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#008300", "#9085e9", "#e66767"],
        pos="#3987e5", neg="#e66767",
        seq=["#0d366b", "#184f95", "#256abf", "#3987e5", "#6da7ec", "#9ec5f4", "#cde2fb"],
    ),
}
FONT = 'system-ui, -apple-system, "Segoe UI", sans-serif'


@dataclass
class Chart:
    id: str
    section: str
    title: str
    caption: str
    fig: go.Figure


def _scale(colors):
    n = len(colors) - 1
    return [[i / n, c] for i, c in enumerate(colors)]


def _base(fig: go.Figure, t: dict, *, height=340, legend=False, x=None, y=None) -> go.Figure:
    fig.update_layout(
        height=height, margin=dict(l=56, r=20, t=16, b=48),
        paper_bgcolor=t["surface"], plot_bgcolor=t["surface"],
        font=dict(family=FONT, size=12, color=t["text2"]),
        showlegend=legend, bargap=0.25,
        legend=dict(orientation="h", y=-0.22, x=0, font=dict(color=t["text2"])),
        hoverlabel=dict(bgcolor=t["surface"], bordercolor=t["axis"],
                        font=dict(family=FONT, color=t["text"])),
    )
    ax = dict(gridcolor=t["grid"], linecolor=t["axis"], zeroline=False,
              tickfont=dict(color=t["muted"]), title_font=dict(color=t["text2"]), ticks="")
    fig.update_xaxes(showgrid=False, **{k: v for k, v in ax.items() if k != "gridcolor"},
                     **({"title_text": x} if x else {}))
    fig.update_yaxes(showgrid=True, **ax, **({"title_text": y} if y else {}))
    return fig


def _round_bars(fig):
    fig.update_traces(selector=dict(type="bar"), marker_cornerradius=4)


def _hist(df, col, t):
    fig = go.Figure(go.Histogram(
        x=df[col], marker=dict(color=t["series"][0], line=dict(color=t["surface"], width=1.5)),
        hovertemplate=f"{col}: %{{x}}<br>count: %{{y}}<extra></extra>"))
    return _base(fig, t, height=300, x=col, y="Count")


def _box_strip(df, col, t):
    fig = go.Figure(go.Box(
        x=df[col], boxpoints="outliers", marker=dict(color=t["series"][0], size=6),
        line=dict(color=t["series"][0], width=2), fillcolor="rgba(0,0,0,0)", name="",
        hovertemplate=f"{col}: %{{x}}<extra></extra>"))
    _base(fig, t, height=130, x=None)
    fig.update_yaxes(showgrid=False, showticklabels=False)
    fig.update_layout(margin=dict(l=56, r=20, t=4, b=36))
    return fig


def _bar_counts(vc: pd.Series, col, t, total):
    vc = vc.sort_values()
    labels = [str(i) for i in vc.index]
    fig = go.Figure(go.Bar(
        y=labels, x=vc.values, orientation="h", marker=dict(color=t["series"][0]),
        customdata=(100 * vc.values / total).round(1),
        hovertemplate="%{y}: %{x} rows (%{customdata}%)<extra></extra>"))
    _base(fig, t, height=max(220, 34 * len(vc) + 90), x="Rows")
    fig.update_xaxes(showgrid=True, gridcolor=t["grid"])
    fig.update_yaxes(showgrid=False, automargin=True)
    _round_bars(fig)
    return fig


def _corr_heatmap(df, cols, t):
    m = df[cols].corr()
    n = len(cols)
    fig = go.Figure(go.Heatmap(
        z=m.values, x=cols, y=cols, zmin=-1, zmax=1, zmid=0,
        colorscale=[[0, t["neg"]], [0.5, t["mid"]], [1, t["pos"]]],
        text=m.values.round(2), texttemplate="%{text}" if n <= 12 else None,
        xgap=2, ygap=2, colorbar=dict(title="r", thickness=12, outlinewidth=0,
                                       tickfont=dict(color=t["muted"]), title_font=dict(color=t["text2"])),
        hovertemplate="%{y} × %{x}<br>r = %{z:.2f}<extra></extra>"))
    _base(fig, t, height=max(340, 46 * n + 120))
    fig.update_yaxes(showgrid=False, autorange="reversed", automargin=True)
    fig.update_xaxes(showgrid=False, tickangle=-35, automargin=True)
    return fig


def _scatter(df, a, b, t):
    d = df[[a, b]].dropna()
    fig = go.Figure(go.Scatter(
        x=d[a], y=d[b], mode="markers", name="Rows",
        marker=dict(color=t["series"][0], size=8, opacity=0.75, line=dict(color=t["surface"], width=1.5)),
        hovertemplate=f"{a}: %{{x}}<br>{b}: %{{y}}<extra></extra>"))
    if len(d) > 2 and d[a].nunique() > 1:
        k, c = np.polyfit(d[a], d[b], 1)
        xs = np.array([d[a].min(), d[a].max()])
        fig.add_trace(go.Scatter(x=xs, y=k * xs + c, mode="lines", name="Linear fit", hoverinfo="skip",
                                 line=dict(color=t["text2"], width=2, dash="dash")))
    fig = _base(fig, t, height=340, legend=True, x=a, y=b)
    fig.update_xaxes(showgrid=True, gridcolor=t["grid"])
    return fig


def _group_box(df, group, metric, t):
    order = df.groupby(group)[metric].median().sort_values().index
    fig = go.Figure()
    for g in order:
        fig.add_trace(go.Box(
            y=df.loc[df[group] == g, metric], name=str(g), boxpoints="outliers",
            marker=dict(color=t["series"][0], size=6), line=dict(color=t["series"][0], width=2),
            fillcolor="rgba(0,0,0,0)", showlegend=False))
    return _base(fig, t, height=340, x=group, y=metric)


def _time_line(df, date, metric, period_label, t):
    freq = {"day": "D", "week": "W", "month": "ME", "year": "YE"}[period_label]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        g = df[[date, metric]].dropna().set_index(date)[metric].resample(freq).mean().dropna()
    fig = go.Figure(go.Scatter(
        x=g.index, y=g.values, mode="lines+markers", name=f"Mean per {period_label}",
        line=dict(color=t["series"][0], width=2), marker=dict(size=8, line=dict(color=t["surface"], width=2)),
        hovertemplate="%{x|%d %b %Y}<br>%{y:.2f}<extra></extra>"))
    if len(g) >= 4:
        k, c = np.polyfit(np.arange(len(g)), g.values, 1)
        fig.add_trace(go.Scatter(x=g.index, y=k * np.arange(len(g)) + c, mode="lines", name="Trend",
                                 hoverinfo="skip", line=dict(color=t["text2"], width=2, dash="dash")))
    fig = _base(fig, t, height=320, legend=True, y=metric)
    fig.update_layout(hovermode="x unified")
    return fig


def _records_over_time(df, date, label, t):
    freq = {"day": "D", "week": "W", "month": "ME", "year": "YE"}[label]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        g = df.set_index(date).resample(freq).size()
    fig = go.Figure(go.Bar(x=g.index, y=g.values, marker=dict(color=t["series"][0]),
                           hovertemplate="%{x|%d %b %Y}: %{y} rows<extra></extra>"))
    _base(fig, t, height=300, y="Rows")
    _round_bars(fig)
    return fig


def _indexed_lines(df, date, metrics, label, t):
    freq = {"day": "D", "week": "W", "month": "ME", "year": "YE"}[label]
    fig = go.Figure()
    for i, m in enumerate(metrics):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            g = df[[date, m]].dropna().set_index(date)[m].resample(freq).mean().dropna()
        if len(g) < 3 or g.iloc[0] == 0:
            continue
        fig.add_trace(go.Scatter(x=g.index, y=100 * g / g.iloc[0], mode="lines", name=m,
                                 line=dict(color=t["series"][i], width=2),
                                 hovertemplate=f"{m}: %{{y:.0f}}<extra></extra>"))
    fig = _base(fig, t, height=340, legend=True, y="Index (first period = 100)")
    fig.update_layout(hovermode="x unified")
    return fig


def _missing_bar(missing: dict[str, int], rows_in: int, t):
    items = sorted(((k, v) for k, v in missing.items() if v), key=lambda kv: kv[1])
    fig = go.Figure(go.Bar(
        y=[k for k, _ in items], x=[100 * v / rows_in for _, v in items], orientation="h",
        marker=dict(color=t["series"][0]), customdata=[v for _, v in items],
        hovertemplate="%{y}: %{customdata} missing (%{x:.1f}%)<extra></extra>"))
    _base(fig, t, height=max(220, 34 * len(items) + 90), x="% of rows missing (before cleaning)")
    fig.update_xaxes(showgrid=True, gridcolor=t["grid"])
    fig.update_yaxes(showgrid=False, automargin=True)
    _round_bars(fig)
    return fig


def _outlier_bar(outliers: dict, t):
    items = sorted(outliers.items(), key=lambda kv: kv[1]["count"])
    fig = go.Figure(go.Bar(y=[k for k, _ in items], x=[v["count"] for _, v in items], orientation="h",
                           marker=dict(color=t["series"][0]),
                           hovertemplate="%{y}: %{x} flagged<extra></extra>"))
    _base(fig, t, height=max(220, 34 * len(items) + 90), x="Flagged outliers")
    fig.update_xaxes(showgrid=True, gridcolor=t["grid"])
    fig.update_yaxes(showgrid=False, automargin=True)
    _round_bars(fig)
    return fig


def _target_bar(rank, target, t):
    rank = sorted(rank, key=lambda r: r["score"])
    fig = go.Figure(go.Bar(y=[r["feature"] for r in rank], x=[r["score"] for r in rank], orientation="h",
                           marker=dict(color=t["series"][0]), customdata=[r["measure"] for r in rank],
                           hovertemplate="%{y}: %{x:.2f}<br>%{customdata}<extra></extra>"))
    _base(fig, t, height=max(240, 34 * len(rank) + 90), x=f"Strength of link to {target}")
    fig.update_xaxes(showgrid=True, gridcolor=t["grid"])
    fig.update_yaxes(showgrid=False, automargin=True)
    _round_bars(fig)
    return fig


def _cat_heatmap(df, a, b, t):
    ct = pd.crosstab(df[a], df[b])
    fig = go.Figure(go.Heatmap(
        z=ct.values, x=[str(c) for c in ct.columns], y=[str(i) for i in ct.index],
        colorscale=_scale(t["seq"]), xgap=2, ygap=2, text=ct.values, texttemplate="%{text}",
        colorbar=dict(title="Rows", thickness=12, outlinewidth=0, tickfont=dict(color=t["muted"]),
                      title_font=dict(color=t["text2"])),
        hovertemplate=f"{a}: %{{y}}<br>{b}: %{{x}}<br>%{{z}} rows<extra></extra>"))
    _base(fig, t, height=max(300, 44 * len(ct) + 120), x=b, y=a)
    fig.update_yaxes(showgrid=False, automargin=True)
    return fig


def build_charts(res: CleanResult, an: Analysis, cfg: Config | None = None, theme: str = "light") -> list[Chart]:
    cfg = cfg or Config()
    t = THEMES[theme]
    df, schema = res.df, res.schema
    cap = cfg.max_charts_per_type
    out: list[Chart] = []

    def add(section, cid, title, caption, fig):
        out.append(Chart(f"{section}-{cid}", section, title, caption, fig))

    # Data quality
    if any(res.missing_before.values()):
        add("quality", "missing", "Missing values by column",
            "Share of rows that were empty before cleaning.",
            _missing_bar(res.missing_before, max(res.rows_in, 1), t))
    if res.outliers:
        add("quality", "outliers", "Flagged outliers by column",
            "Values outside the outlier bounds. They are flagged, not removed.", _outlier_bar(res.outliers, t))

    # Numeric distributions
    nums = [c for c, k in schema.items() if k == NUMERIC]
    for c in nums[:cap]:
        p = an.numeric.get(c, {})
        cap_txt = (f"Median {p.get('median'):.4g}, mean {p.get('mean'):.4g}, std {p.get('std'):.4g}."
                   if p else "Distribution of values.")
        add("numeric", c, f"Distribution of {c}", cap_txt, _hist(df, c, t))
        add("numeric", c + "-box", f"Spread of {c}", "Box shows the middle 50%; dots are outliers.",
            _box_strip(df, c, t))

    # Categorical breakdowns
    cats = [c for c, k in schema.items() if k in (CATEGORICAL, BOOLEAN)]
    for c in cats[:cap]:
        vc = df[c].astype(str).value_counts().head(cfg.max_categories_shown)
        add("categorical", c, f"{c}: rows per category",
            f"{df[c].nunique()} distinct value(s)"
            + (f"; top {cfg.max_categories_shown} shown." if df[c].nunique() > cfg.max_categories_shown else "."),
            _bar_counts(vc, c, t, len(df)))

    # Relationships
    if len(nums) >= 2:
        add("relationships", "corr", "Correlation heatmap",
            "Pearson correlation between numeric columns. Blue = move together, red = move opposite.",
            _corr_heatmap(df, nums[:30], t))
        for pr in an.corr_pairs[:6]:
            add("relationships", f"{pr['a']}-{pr['b']}", f"{pr['a']} vs {pr['b']}",
                f"r = {pr['pearson']:.2f} (Spearman {pr['spearman']:.2f}).", _scatter(df, pr["a"], pr["b"], t))
    for e in an.group_effects[:4]:
        add("relationships", f"{e['group']}-{e['metric']}", f"{e['metric']} by {e['group']}",
            f"Groups differ significantly (p = {e['p']:.3g}).", _group_box(df, e["group"], e["metric"], t))
    for a in an.cat_associations[:2]:
        add("relationships", f"{a['a']}-{a['b']}", f"{a['a']} × {a['b']}",
            f"Associated (Cramér's V = {a['cramers_v']:.2f}).", _cat_heatmap(df, a["a"], a["b"], t))
    if an.target_ranking:
        add("relationships", "target", f"What relates most to {cfg.target}",
            "Higher bar = stronger statistical link (not proof of cause).",
            _target_bar(an.target_ranking, cfg.target, t))

    # Time
    dts = [c for c, k in schema.items() if k == DATETIME]
    if dts:
        dc = dts[0]
        meta = an.datetime.get(dc)
        if meta and meta["span_days"] >= 7:
            from .analyze import _trend_period
            _, label = _trend_period(meta["span_days"])
            add("time", "records", f"Records over time ({dc})", f"Rows per {label}.",
                _records_over_time(df, dc, label, t))
            trends = sorted([x for x in an.trends if x["date"] == dc], key=lambda x: x["p"] or 1)
            for tr in trends[:6]:
                add("time", f"{dc}-{tr['metric']}", f"{tr['metric']} over time",
                    f"Mean per {tr['period']}; trend {'up' if tr['slope'] > 0 else 'down'} "
                    f"({tr['pct_change']:+.0f}%, p = {tr['p']:.3g}).",
                    _time_line(df, dc, tr["metric"], tr["period"], t))
            if len(trends) >= 2:
                add("time", "indexed", "Metrics compared on one scale",
                    "Each metric indexed to 100 at the first period so different units can share an axis.",
                    _indexed_lines(df, dc, [x["metric"] for x in trends[:4]], trends[0]["period"], t))
    return out

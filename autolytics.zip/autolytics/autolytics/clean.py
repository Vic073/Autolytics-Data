"""Rule-driven, fully logged data cleaning and type inference."""
from __future__ import annotations

import re
import warnings
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .config import Config

NA_TOKENS = {
    "", "na", "n/a", "n.a.", "nan", "null", "none", "nil", "missing", "unknown",
    "undefined", "-", "--", "?", "#n/a", "#na", "not available", "not recorded",
}
TRUE_TOKENS = {"yes", "y", "true", "t", "positive", "pos"}
FALSE_TOKENS = {"no", "n", "false", "f", "negative", "neg"}
ID_NAME = re.compile(r"(^|_)(id|uuid|guid|index|idx|no|number|code|ref|key)$")

# Kinds the rest of the pipeline understands.
NUMERIC, CATEGORICAL, DATETIME, BOOLEAN, TEXT, ID, CONSTANT = (
    "numeric", "categorical", "datetime", "boolean", "text", "id", "constant",
)


@dataclass
class CleanResult:
    df: pd.DataFrame
    schema: dict[str, str]
    log: list[dict] = field(default_factory=list)
    outliers: dict[str, dict] = field(default_factory=dict)
    missing_before: dict[str, int] = field(default_factory=dict)
    renamed: dict[str, str] = field(default_factory=dict)
    dropped_columns: list[str] = field(default_factory=list)
    rows_in: int = 0
    rows_out: int = 0

    def add(self, step: str, action: str, column: str | None = None, count: int | None = None):
        self.log.append({"step": step, "column": column, "action": action, "count": count})


def _snake(name: str) -> str:
    s = re.sub(r"[^0-9a-zA-Z]+", "_", str(name).strip())
    s = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", s)
    s = s.strip("_").lower()
    return s or "column"


def _standardize_columns(df: pd.DataFrame, res: CleanResult) -> pd.DataFrame:
    new, seen = [], {}
    for old in df.columns:
        base = _snake(old)
        if base.startswith("unnamed"):
            base = "unnamed"
        n = seen.get(base, 0)
        seen[base] = n + 1
        name = base if n == 0 else f"{base}_{n + 1}"
        new.append(name)
        if name != str(old):
            res.renamed[str(old)] = name
    changed = len(res.renamed)
    df.columns = new
    if changed:
        res.add("columns", f"Standardised {changed} column name(s) to snake_case", count=changed)
    return df


def _normalise_strings(df: pd.DataFrame, res: CleanResult) -> pd.DataFrame:
    for col in df.columns:
        if df[col].dtype == object or pd.api.types.is_string_dtype(df[col]):
            s = df[col].astype("object")
            was_na = s.isna().sum()
            stripped = s.map(lambda v: re.sub(r"\s+", " ", v).strip() if isinstance(v, str) else v)
            trimmed = int(((stripped != s) & s.notna()).sum())
            is_na_token = stripped.map(lambda v: isinstance(v, str) and v.lower() in NA_TOKENS)
            stripped = stripped.mask(is_na_token, np.nan)
            df[col] = stripped
            if trimmed:
                res.add("strings", "Trimmed/collapsed whitespace", col, trimmed)
            new_na = int(df[col].isna().sum() - was_na)
            if new_na > 0:
                res.add("missing", "Converted placeholder text (N/A, null, -, ...) to missing", col, new_na)
    return df


_NUM_STRIP = re.compile(r"[,\s$£€¥%]|^MK|^KES|^USD|^ZAR|^EUR|^GBP", re.IGNORECASE)
_UNIT_SUFFIX = re.compile(r"^(-?\(?[\d.,]+)\s*([A-Za-z%/°]{1,6}(?:/[A-Za-z]{1,4})?)\)?$")


def _try_numeric(s: pd.Series) -> tuple[pd.Series | None, str]:
    nn = s.dropna()
    if nn.empty:
        return None, ""
    strs = nn.astype(str)
    # Keep leading-zero codes (e.g. 00123) as text identifiers.
    if strs.str.match(r"^0\d+$").mean() > 0.5:
        return None, ""

    units: set[str] = set()

    def conv(v: str):
        v = v.strip()
        neg = v.startswith("(") and v.endswith(")")
        v = v.strip("()")
        m = _UNIT_SUFFIX.match(v)
        if m and not re.fullmatch(r"[\d.,]+", v):
            # "72 kg", "5.4mmol/L": number followed by a short unit. Only trusted when
            # the column uses very few distinct units (see check below).
            units.add(m.group(2).lower())
            v = m.group(1)
        v = _NUM_STRIP.sub("", v)
        try:
            x = float(v)
        except ValueError:
            return np.nan
        return -x if neg else x

    parsed = s.map(lambda v: conv(v) if isinstance(v, str) else v)
    parsed = pd.to_numeric(parsed, errors="coerce")
    ratio = parsed.notna().sum() / len(nn)
    if len(units) > 2:      # many different suffixes looks like codes (e.g. 12A, 7B), not units
        return None, ""
    if ratio >= 0.9:
        note = "Parsed text as numbers (stripped separators/currency/%/units)"
        lost = int(len(nn) - parsed.notna().sum())
        if units:
            note += f" [units seen: {', '.join(sorted(units))}]"
        return parsed, note + (f"; {lost} unparseable value(s) set to missing" if lost else "")
    return None, ""


_DAY_FIRST = re.compile(r"^\s*(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})\s*$")


def _looks_day_first(strs: pd.Series) -> bool:
    """True when slash/dash dates only make sense as dd/mm (some first part > 12, no second part > 12)."""
    firsts, seconds = [], []
    for v in strs:
        m = _DAY_FIRST.match(v)
        if m:
            firsts.append(int(m.group(1)))
            seconds.append(int(m.group(2)))
    return bool(firsts) and max(firsts) > 12 and max(seconds) <= 12


def _try_datetime(s: pd.Series, min_ratio: float) -> pd.Series | None:
    nn = s.dropna().astype(str)
    if nn.empty:
        return None
    # Cheap pre-check so ordinary words never get parsed as dates.
    if not nn.str.contains(r"\d").mean() > 0.9:
        return None
    if not nn.str.contains(r"[-/.:]|\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)", case=False).mean() > 0.9:
        return None
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        dayfirst = _looks_day_first(nn)
        try:
            parsed = pd.to_datetime(s, errors="coerce", format="mixed", dayfirst=dayfirst)
        except (TypeError, ValueError):
            parsed = pd.to_datetime(s, errors="coerce", dayfirst=dayfirst)
    if parsed.notna().sum() / len(nn) >= min_ratio:
        return parsed
    return None


def _try_boolean(s: pd.Series) -> pd.Series | None:
    nn = s.dropna()
    if nn.empty or nn.nunique() > 2:
        return None
    toks = {str(v).strip().lower() for v in nn.unique()}
    if toks <= (TRUE_TOKENS | FALSE_TOKENS):
        return s.map(lambda v: np.nan if pd.isna(v) else str(v).strip().lower() in TRUE_TOKENS)
    return None


def _infer_types(df: pd.DataFrame, cfg: Config, res: CleanResult) -> pd.DataFrame:
    for col in df.columns:
        s = df[col]
        if pd.api.types.is_bool_dtype(s) or pd.api.types.is_datetime64_any_dtype(s) \
                or pd.api.types.is_numeric_dtype(s):
            continue
        b = _try_boolean(s)
        if b is not None:
            df[col] = b.astype("object")
            res.add("types", "Converted yes/no style text to boolean", col, int(s.notna().sum()))
            continue
        n, note = _try_numeric(s)
        if n is not None:
            df[col] = n
            res.add("types", note, col, int(s.notna().sum()))
            continue
        d = _try_datetime(s, cfg.datetime_min_parse_ratio)
        if d is not None:
            df[col] = d
            res.add("types", "Parsed text as dates", col, int(d.notna().sum()))
    return df


def _normalise_case(df: pd.DataFrame, res: CleanResult) -> pd.DataFrame:
    """Merge category spellings that differ only by case ('male', 'MALE', 'Male' -> the most common form)."""
    for col in df.columns:
        s = df[col]
        if not (s.dtype == object or pd.api.types.is_string_dtype(s)):
            continue
        vals = s.dropna()
        if vals.empty or not vals.map(lambda v: isinstance(v, str)).all():
            continue
        if vals.nunique() > 60 or vals.nunique() / len(vals) > 0.5:
            continue
        counts = vals.value_counts()
        canon = {}
        for k in counts.index:                       # most common spelling first
            canon.setdefault(k.casefold(), k)
        mapped = s.map(lambda v: canon.get(v.casefold(), v) if isinstance(v, str) else v)
        changed = int(((mapped != s) & s.notna()).sum())
        if changed:
            df[col] = mapped
            res.add("categories", "Merged spellings that differed only by letter case", col, changed)
    return df


def _classify(s: pd.Series, name: str, cfg: Config) -> str:
    nn = s.dropna()
    n, u = len(nn), nn.nunique()
    if n == 0 or u <= 1:
        return CONSTANT
    if pd.api.types.is_datetime64_any_dtype(s):
        return DATETIME
    if pd.api.types.is_bool_dtype(s) or set(map(str, nn.unique())) <= {"True", "False"}:
        return BOOLEAN
    if pd.api.types.is_numeric_dtype(s):
        integer_like = bool((nn % 1 == 0).all())
        if integer_like and u == n and n > 1 and (ID_NAME.search(name) or nn.is_monotonic_increasing):
            return ID
        if integer_like and u <= min(cfg.category_max_unique, 10):
            return CATEGORICAL
        return NUMERIC
    avg_len = nn.astype(str).str.len().mean()
    if n > 20 and u / n >= cfg.id_unique_ratio:
        return TEXT if avg_len > 40 else ID
    if avg_len > 60 and u / n > 0.5:
        return TEXT
    return CATEGORICAL


def _flag_outliers(df: pd.DataFrame, schema: dict[str, str], cfg: Config, res: CleanResult):
    if cfg.outlier_method == "none":
        return
    for col, kind in schema.items():
        if kind != NUMERIC:
            continue
        s = df[col].dropna()
        if len(s) < 8:
            continue
        if cfg.outlier_method == "zscore":
            sd = s.std()
            if not sd:
                continue
            z = (df[col] - s.mean()) / sd
            mask = z.abs() > cfg.outlier_z
            lo, hi = s.mean() - cfg.outlier_z * sd, s.mean() + cfg.outlier_z * sd
        else:
            q1, q3 = s.quantile(0.25), s.quantile(0.75)
            iqr = q3 - q1
            if iqr == 0:
                continue
            lo, hi = q1 - cfg.outlier_iqr_k * iqr, q3 + cfg.outlier_iqr_k * iqr
            mask = (df[col] < lo) | (df[col] > hi)
        count = int(mask.sum())
        if count:
            res.outliers[col] = {
                "count": count, "lower": float(lo), "upper": float(hi),
                "rows": [int(i) for i in df.index[mask]][:200],
            }
            if cfg.clip_outliers:
                df[col] = df[col].clip(lo, hi)
                res.add("outliers", f"Clipped to [{lo:.4g}, {hi:.4g}]", col, count)
            else:
                res.add("outliers", f"Flagged outside [{lo:.4g}, {hi:.4g}] (values kept)", col, count)


def _impute(df: pd.DataFrame, schema: dict[str, str], cfg: Config, res: CleanResult):
    for col, kind in schema.items():
        miss = int(df[col].isna().sum())
        if not miss:
            continue
        if kind == NUMERIC and cfg.numeric_impute != "none":
            fill = df[col].median() if cfg.numeric_impute == "median" else df[col].mean()
            df[col] = df[col].fillna(fill)
            res.add("missing", f"Filled with {cfg.numeric_impute} ({fill:.4g})", col, miss)
        elif kind in (CATEGORICAL, BOOLEAN, TEXT) and cfg.categorical_impute != "none":
            if cfg.categorical_impute == "mode" and not df[col].mode().empty:
                fill = df[col].mode().iloc[0]
            else:
                fill = "Unknown" if cfg.categorical_impute == "mode" else cfg.categorical_impute
            if kind == BOOLEAN:
                continue  # never invent a yes/no; leave as missing
            if pd.api.types.is_numeric_dtype(df[col]):
                fill = df[col].mode().iloc[0] if not df[col].mode().empty else 0
            df[col] = df[col].fillna(fill)
            res.add("missing", f"Filled with {fill!r}", col, miss)
        elif kind == DATETIME:
            res.add("missing", "Left missing dates untouched (not safe to guess)", col, miss)


def clean(df: pd.DataFrame, cfg: Config | None = None) -> CleanResult:
    cfg = cfg or Config()
    df = df.copy()
    res = CleanResult(df=df, schema={}, rows_in=len(df))

    df = _standardize_columns(df, res)
    df = _normalise_strings(df, res)
    df = _infer_types(df, cfg, res)
    df = _normalise_case(df, res)
    res.missing_before = {c: int(df[c].isna().sum()) for c in df.columns}

    if cfg.drop_duplicates:
        dup = int(df.duplicated().sum())
        if dup:
            df = df.drop_duplicates().reset_index(drop=True)
            res.add("rows", "Removed exact duplicate rows", count=dup)

    thr = cfg.missing_drop_col_threshold
    heavy = [c for c in df.columns if df[c].isna().mean() > thr]
    if heavy:
        df = df.drop(columns=heavy)
        res.dropped_columns = heavy
        for c in heavy:
            res.add("columns", f"Dropped: more than {thr:.0%} missing", c, res.missing_before[c])

    schema = {c: _classify(df[c], c, cfg) for c in df.columns}
    _flag_outliers(df, schema, cfg, res)
    _impute(df, schema, cfg, res)
    schema = {c: _classify(df[c], c, cfg) for c in df.columns}  # re-check after imputation

    res.df, res.schema, res.rows_out = df, schema, len(df)
    if not res.log:
        res.add("summary", "Data was already clean; no changes needed")
    return res

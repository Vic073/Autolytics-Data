"""Spot columns that look like personal identifiers and optionally hash or drop them.

Health, HR and student data usually carry names, phone numbers or national IDs. Run with
`anonymize="hash"` (stable pseudonyms, so rows can still be joined) or `"drop"` before sharing outputs.
"""
from __future__ import annotations

import hashlib
import re

import pandas as pd

NAME_HINTS = re.compile(
    r"(^|[_\s])(name|surname|firstname|lastname|fullname|phone|mobile|tel|telephone|email|e_?mail|"
    r"address|nid|national_?id|passport|ssn|dob|birth_?date|date_of_birth|next_of_kin|guardian)($|[_\s])",
    re.IGNORECASE)
EMAIL = re.compile(r"^[\w.+-]+@[\w-]+\.[\w.-]+$")
PHONE = re.compile(r"^\+?[\d\s()-]{9,16}$")


def detect_pii(df: pd.DataFrame) -> dict[str, str]:
    """Return {column: reason} for columns that look like direct identifiers."""
    found: dict[str, str] = {}
    for col in df.columns:
        if NAME_HINTS.search(str(col).strip()):
            found[str(col)] = "column name suggests a personal identifier"
            continue
        s = df[col].dropna().astype(str).str.strip()
        if len(s) < 5 or pd.api.types.is_numeric_dtype(df[col]):
            continue
        s = s.head(200)
        if s.map(lambda v: bool(EMAIL.match(v))).mean() > 0.6:
            found[str(col)] = "values look like email addresses"
        elif s.map(lambda v: bool(PHONE.match(v)) and sum(c.isdigit() for c in v) >= 9).mean() > 0.6:
            found[str(col)] = "values look like phone numbers"
    return found


def _hash(v, salt: str) -> str:
    return "anon_" + hashlib.sha256((salt + str(v)).encode()).hexdigest()[:10]


def anonymize(df: pd.DataFrame, cols: list[str], mode: str, salt: str = "") -> pd.DataFrame:
    df = df.copy()
    if mode == "drop":
        return df.drop(columns=[c for c in cols if c in df.columns])
    if mode == "hash":
        for c in cols:
            if c in df.columns:
                df[c] = df[c].map(lambda v: v if pd.isna(v) else _hash(v, salt))
    return df

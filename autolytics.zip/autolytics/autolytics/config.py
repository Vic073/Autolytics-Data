"""Pipeline configuration. Every option has a sensible default so zero config works."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any


@dataclass
class Config:
    # --- ingest ---
    sheet: str | int | None = None          # Excel sheet / SQLite table (None = first)
    # --- privacy ---
    anonymize: str = "none"                  # none | hash | drop  (applies to detected personal-identifier columns)
    anonymize_columns: list[str] | None = None  # explicit columns to treat as identifiers (adds to detection)
    # --- clean ---
    drop_duplicates: bool = True
    missing_drop_col_threshold: float = 0.6  # drop columns with more than this share missing
    numeric_impute: str = "median"           # median | mean | none
    categorical_impute: str = "Unknown"      # fill value, or "mode", or "none"
    outlier_method: str = "iqr"              # iqr | zscore | none
    outlier_iqr_k: float = 1.5
    outlier_z: float = 3.0
    clip_outliers: bool = False              # flag by default, never silently alter
    id_unique_ratio: float = 0.95            # text cols this unique are treated as identifiers
    category_max_unique: int = 20            # numeric cols with <= this many values may be categorical
    datetime_min_parse_ratio: float = 0.8    # share of values that must parse to call it a date
    # --- analyze ---
    top_correlations: int = 8
    corr_threshold: float = 0.3
    max_categories_shown: int = 12
    target: str | None = None                # optional column to focus the analysis on
    # --- visualize ---
    max_charts_per_type: int = 12
    # --- report ---
    title: str = "Data Analysis Report"
    dark_mode_default: bool = False

    @classmethod
    def load(cls, path: str | Path | None = None, **overrides: Any) -> "Config":
        data: dict[str, Any] = {}
        if path:
            p = Path(path)
            text = p.read_text(encoding="utf-8")
            if p.suffix.lower() in {".yml", ".yaml"}:
                import yaml

                data = yaml.safe_load(text) or {}
            else:
                data = json.loads(text)
        data.update({k: v for k, v in overrides.items() if v is not None})
        valid = {f.name for f in fields(cls)}
        unknown = set(data) - valid
        if unknown:
            raise ValueError(f"Unknown config option(s): {sorted(unknown)}")
        return cls(**data)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

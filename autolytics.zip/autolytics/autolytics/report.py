"""Self-contained HTML report: one file, works offline, light/dark toggle, lazy-rendered charts."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd
from jinja2 import Environment
from plotly.offline import get_plotlyjs

from .analyze import Analysis
from .clean import CleanResult
from .config import Config
from .visualize import Chart

SECTIONS = [
    ("quality", "Data quality", "What was missing or unusual in the raw data."),
    ("numeric", "Numeric columns", "Shape and spread of every measurement."),
    ("categorical", "Categories", "How rows split across groups."),
    ("relationships", "Relationships", "Which columns move together or differ across groups."),
    ("time", "Over time", "Trends across the date column."),
]
LEVELS = {"info": ("Info", "i"), "notable": ("Finding", "◆"), "warning": ("Check", "!")}

TEMPLATE = r"""<!doctype html>
<html lang="en" data-theme="{{ 'dark' if dark else 'light' }}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{ title }}</title>
<style>
:root{--page:#f9f9f7;--surface:#fcfcfb;--text:#0b0b0b;--text2:#52514e;--muted:#898781;--line:rgba(11,11,11,.10);
--grid:#e1e0d9;--accent:#2a78d6;--accent-ink:#184f95;--good:#006300;--warn:#8a5a00;color-scheme:light}
:root[data-theme=dark]{--page:#0d0d0d;--surface:#1a1a19;--text:#f0efec;--text2:#c3c2b7;--muted:#898781;
--line:rgba(255,255,255,.10);--grid:#2c2c2a;--accent:#3987e5;--accent-ink:#9ec5f4;--good:#0ca30c;--warn:#fab219;color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;background:var(--page);color:var(--text);font:15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:0 20px 80px}
header{display:flex;gap:16px;justify-content:space-between;align-items:flex-start;padding:36px 0 20px;flex-wrap:wrap}
h1{font-size:28px;margin:0 0 4px;letter-spacing:-.01em}
.sub{color:var(--text2);font-size:13px}
button.theme{border:1px solid var(--line);background:var(--surface);color:var(--text);border-radius:8px;padding:8px 12px;cursor:pointer;font:inherit;font-size:13px}
button.theme:hover{border-color:var(--accent)}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:8px 0 28px}
.kpi{background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:14px 16px}
.kpi b{display:block;font-size:26px;letter-spacing:-.01em}
.kpi span{color:var(--text2);font-size:12px}
h2{font-size:20px;margin:40px 0 2px;letter-spacing:-.01em}
.lead{color:var(--text2);margin:0 0 16px;font-size:13px}
.card{background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:16px}
.insights{list-style:none;margin:0;padding:0;display:grid;gap:8px}
.insights li{display:flex;gap:12px;align-items:baseline;padding:10px 14px;border:1px solid var(--line);border-radius:10px;background:var(--surface)}
.tag{flex:none;font-size:11px;font-weight:600;letter-spacing:.04em;text-transform:uppercase;min-width:64px;color:var(--text2)}
.tag.warning{color:var(--warn)}.tag.notable{color:var(--accent-ink)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(480px,1fr));gap:16px}
@media(max-width:560px){.grid{grid-template-columns:1fr}}
.chart h3{font-size:15px;margin:0 0 2px}.chart p{margin:0 0 8px;color:var(--text2);font-size:12.5px}
.plot{min-height:120px}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{text-align:left;padding:7px 10px;border-bottom:1px solid var(--line)}
th{color:var(--text2);font-weight:600;position:sticky;top:0;background:var(--surface)}
td.num{text-align:right;font-variant-numeric:tabular-nums}
.scroll{max-height:420px;overflow:auto}
details{margin-top:12px}summary{cursor:pointer;color:var(--text2)}
code,pre{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px}
footer{margin-top:48px;color:var(--muted);font-size:12px}
@media print{button.theme{display:none}.card,.kpi{break-inside:avoid}}
</style>
</head>
<body><div class="wrap">
<header>
  <div><h1>{{ title }}</h1>
  <div class="sub">{{ source }} · generated {{ generated }}</div></div>
  <button class="theme" id="tbtn" type="button">Toggle theme</button>
</header>

<div class="kpis">
{% for label, val in kpis %}<div class="kpi"><b>{{ val }}</b><span>{{ label }}</span></div>{% endfor %}
</div>

<h2>Key insights</h2>
<p class="lead">Generated automatically from the data. Treat as leads to investigate, not conclusions.</p>
<ul class="insights">
{% for i in insights %}<li><span class="tag {{ i.level }}">{{ i.tag }}</span><span>{{ i.text }}</span></li>{% endfor %}
</ul>

{% for key, name, blurb, charts in sections %}
<h2>{{ name }}</h2><p class="lead">{{ blurb }}</p>
<div class="grid">
{% for c in charts %}<div class="card chart"><h3>{{ c.title }}</h3><p>{{ c.caption }}</p>
<div class="plot" data-id="{{ c.dom }}"></div></div>{% endfor %}
</div>
{% endfor %}

<h2>Columns</h2><p class="lead">Detected type and cleaning impact per column.</p>
<div class="card scroll"><table>
<tr><th>Column</th><th>Original name</th><th>Detected as</th><th class="num">Missing (raw)</th><th class="num">Outliers</th></tr>
{% for r in schema_rows %}<tr><td><code>{{ r.col }}</code></td><td>{{ r.orig }}</td><td>{{ r.kind }}</td>
<td class="num">{{ r.missing }}</td><td class="num">{{ r.outliers }}</td></tr>{% endfor %}
</table></div>

<h2>Cleaning log</h2><p class="lead">Every change the pipeline made, so the result is traceable.</p>
<div class="card scroll"><table>
<tr><th>Step</th><th>Column</th><th>Action</th><th class="num">Count</th></tr>
{% for e in log %}<tr><td>{{ e.step }}</td><td>{{ e.column or '—' }}</td><td>{{ e.action }}</td>
<td class="num">{{ e.count if e.count is not none else '—' }}</td></tr>{% endfor %}
</table></div>

<details><summary>Settings used</summary><pre>{{ config_text }}</pre></details>
<footer>Created with autolytics. Rows analysed: {{ rows }}.</footer>
</div>

{% for c in all_charts %}
<script type="application/json" id="{{ c.dom }}-light">{{ c.light|safe }}</script>
<script type="application/json" id="{{ c.dom }}-dark">{{ c.dark|safe }}</script>
{% endfor %}
<script>{{ plotly_js|safe }}</script>
<script>
(function(){
  var root=document.documentElement, rendered=new Set();
  var saved=null; try{saved=localStorage.getItem('autolytics-theme')}catch(e){}
  if(saved){root.dataset.theme=saved}
  else if(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches&&!{{ 'true' if forced else 'false' }}){root.dataset.theme='dark'}
  function draw(el){
    var n=document.getElementById(el.dataset.id+'-'+root.dataset.theme); if(!n) return;
    var f=JSON.parse(n.textContent);
    Plotly.react(el,f.data,f.layout,{responsive:true,displaylogo:false,modeBarButtonsToRemove:['lasso2d','select2d']});
    rendered.add(el);
  }
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){draw(e.target);io.unobserve(e.target)}})},{rootMargin:'400px'});
  document.querySelectorAll('.plot').forEach(function(el){io.observe(el)});
  document.getElementById('tbtn').addEventListener('click',function(){
    root.dataset.theme=root.dataset.theme==='dark'?'light':'dark';
    try{localStorage.setItem('autolytics-theme',root.dataset.theme)}catch(e){}
    rendered.forEach(draw);
  });
  window.addEventListener('beforeprint',function(){document.querySelectorAll('.plot').forEach(function(el){if(!rendered.has(el))draw(el)})});
})();
</script>
</body></html>
"""


def _kpis(an: Analysis):
    o = an.overview
    return [
        ("Rows", f"{o['rows']:,}"), ("Columns", o["columns"]),
        ("Numeric columns", o["kinds"].get("numeric", 0)),
        ("Categorical columns", o["kinds"].get("categorical", 0) + o["kinds"].get("boolean", 0)),
        ("Missing cells (raw)", f"{o['missing_cells_before']:,}"),
        ("Outliers flagged", f"{o['total_outliers']:,}"),
        ("Duplicates removed", o["duplicates_removed"]),
    ]


def _json(fig) -> str:
    return fig.to_json().replace("</", "<\\/")


def render_report(res: CleanResult, an: Analysis, charts_light: list[Chart], charts_dark: list[Chart],
                  cfg: Config, source: str, path: str | Path) -> Path:
    dark_by_id = {c.id: c for c in charts_dark}
    prepared, by_section = [], {}
    for i, c in enumerate(charts_light):
        d = dark_by_id.get(c.id, c)
        item = {"dom": f"c{i}", "title": c.title, "caption": c.caption,
                "light": _json(c.fig), "dark": _json(d.fig)}
        prepared.append(item)
        by_section.setdefault(c.section, []).append(item)

    sections = [(k, n, b, by_section[k]) for k, n, b in SECTIONS if k in by_section]
    inv = {v: k for k, v in res.renamed.items()}
    schema_rows = [{
        "col": c, "orig": inv.get(c, c), "kind": k,
        "missing": res.missing_before.get(c, 0), "outliers": res.outliers.get(c, {}).get("count", 0),
    } for c, k in res.schema.items()]
    insights = [{"level": i["level"], "tag": LEVELS[i["level"]][0], "text": i["text"]} for i in an.insights]
    cfg_text = "\n".join(f"{k}: {v}" for k, v in cfg.to_dict().items())

    env = Environment(autoescape=True)
    html = env.from_string(TEMPLATE).render(
        title=cfg.title, source=source, generated=datetime.now().strftime("%d %b %Y, %H:%M"),
        kpis=_kpis(an), insights=insights, sections=sections, all_charts=prepared,
        schema_rows=schema_rows, log=res.log, config_text=cfg_text, rows=f"{res.rows_out:,}",
        plotly_js=get_plotlyjs(), dark=cfg.dark_mode_default, forced=cfg.dark_mode_default,
    )
    path = Path(path)
    path.write_text(html, encoding="utf-8")
    return path

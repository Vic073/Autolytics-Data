"""Type-aware statistical analysis plus plain-English insight generation."""
from __future__ import annotations

import warnings
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import stats

from .clean import BOOLEAN, CATEGORICAL, DATETIME, NUMERIC, CleanResult
from .config import Config


@dataclass
class Analysis:
    overview: dict = field(default_factory=dict)
    numeric: dict = field(default_factory=dict)
    categorical: dict = field(default_factory=dict)
    datetime: dict = field(default_factory=dict)
    corr_pairs: list = field(default_factory=list)
    group_effects: list = field(default_factory=list)
    cat_associations: list = field(default_factory=list)
    trends: list = field(default_factory=list)
    target_ranking: list = field(default_factory=list)
    insights: list = field(default_factory=list)


def _r(x, n=4):
    try:
        x = float(x)
    except (TypeError, ValueError):
        return None
    return None if np.isnan(x) or np.isinf(x) else round(x, n)


def _fmt(x) -> str:
    x = float(x)
    if abs(x) >= 1000:
        return f"{x:,.0f}"
    if abs(x) >= 10:
        return f"{x:.1f}"
    return f"{x:.2f}"


def eta_squared(groups: pd.Series, values: pd.Series) -> float:
    d = pd.DataFrame({"g": groups, "v": values}).dropna()
    if d["g"].nunique() < 2 or len(d) < 3:
        return float("nan")
    grand = d["v"].mean()
    ss_tot = ((d["v"] - grand) ** 2).sum()
    if ss_tot == 0:
        return float("nan")
    ss_b = d.groupby("g")["v"].apply(lambda x: len(x) * (x.mean() - grand) ** 2).sum()
    return float(ss_b / ss_tot)


def cramers_v(a: pd.Series, b: pd.Series) -> tuple[float, float]:
    d = pd.DataFrame({"a": a, "b": b}).dropna()
    if len(d) < 20:
        return float("nan"), float("nan")
    ct = pd.crosstab(d["a"], d["b"])
    if ct.shape[0] < 2 or ct.shape[1] < 2:
        return float("nan"), float("nan")
    chi2, p, _, _ = stats.chi2_contingency(ct, correction=False)
    v = np.sqrt(chi2 / (len(d) * (min(ct.shape) - 1)))
    return float(v), float(p)


def _strength(r: float) -> str:
    a = abs(r)
    return "very strong" if a >= 0.8 else "strong" if a >= 0.6 else "moderate" if a >= 0.4 else "weak"


def _numeric_profile(df, cols):
    out = {}
    for c in cols:
        s = df[c].dropna()
        if s.empty:
            continue
        mean, sd = s.mean(), s.std()
        out[c] = {
            "count": int(s.count()), "mean": _r(mean), "std": _r(sd), "min": _r(s.min()),
            "q1": _r(s.quantile(0.25)), "median": _r(s.median()), "q3": _r(s.quantile(0.75)),
            "max": _r(s.max()), "skew": _r(s.skew()) if len(s) > 2 else None,
            "kurtosis": _r(s.kurt()) if len(s) > 3 else None,
            "cv": _r(sd / mean) if mean else None,
        }
    return out


def _categorical_profile(df, cols, top):
    out = {}
    for c in cols:
        vc = df[c].value_counts(dropna=True)
        total = int(vc.sum())
        out[c] = {
            "unique": int(len(vc)), "total": total,
            "top": [{"value": str(k), "count": int(v), "pct": _r(100 * v / total, 1)}
                    for k, v in vc.head(top).items()],
            "dominant_pct": _r(100 * vc.iloc[0] / total, 1) if total else None,
        }
    return out


def _trend_period(span_days: float) -> tuple[str, str]:
    if span_days <= 45:
        return "D", "day"
    if span_days <= 400:
        return "W", "week"
    if span_days <= 365 * 6:
        return "ME", "month"
    return "YE", "year"


def _trends(df, schema, cfg):
    dts = [c for c, k in schema.items() if k == DATETIME]
    nums = [c for c, k in schema.items() if k == NUMERIC]
    out, meta = [], {}
    for dc in dts[:2]:
        d = df[dc].dropna()
        if d.empty:
            continue
        span = (d.max() - d.min()).days
        meta[dc] = {"min": str(d.min().date()), "max": str(d.max().date()), "span_days": int(span)}
        if span < 7:
            continue
        freq, label = _trend_period(span)
        for nc in nums[:12]:
            sub = df[[dc, nc]].dropna()
            if len(sub) < 8:
                continue
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                g = sub.set_index(dc)[nc].resample(freq).mean().dropna()
            if len(g) < 4:
                continue
            x = np.arange(len(g))
            lr = stats.linregress(x, g.values)
            first, last = g.iloc[: max(1, len(g) // 4)].mean(), g.iloc[-max(1, len(g) // 4):].mean()
            pct = (last - first) / abs(first) * 100 if first else float("nan")
            out.append({"date": dc, "metric": nc, "period": label, "periods": int(len(g)),
                        "slope": _r(lr.slope), "r": _r(lr.rvalue), "p": _r(lr.pvalue, 5),
                        "pct_change": _r(pct, 1)})
    return out, meta


def analyze(res: CleanResult, cfg: Config | None = None) -> Analysis:
    cfg = cfg or Config()
    df, schema = res.df, res.schema
    A = Analysis()
    kinds = pd.Series(schema).value_counts().to_dict()
    nums = [c for c, k in schema.items() if k == NUMERIC]
    cats = [c for c, k in schema.items() if k in (CATEGORICAL, BOOLEAN)]
    A.overview = {
        "rows": res.rows_out, "rows_in": res.rows_in, "columns": len(df.columns),
        "kinds": {k: int(v) for k, v in kinds.items()},
        "missing_cells_before": int(sum(res.missing_before.values())),
        "duplicates_removed": next((e["count"] for e in res.log if e["action"].startswith("Removed exact")), 0),
        "outlier_columns": len(res.outliers),
        "total_outliers": int(sum(o["count"] for o in res.outliers.values())),
    }
    A.numeric = _numeric_profile(df, nums)
    A.categorical = _categorical_profile(df, cats, cfg.max_categories_shown)
    A.trends, A.datetime = _trends(df, schema, cfg)

    # Correlations (Pearson + Spearman agreement filter keeps weak monotone noise out)
    if len(nums) >= 2:
        pear = df[nums].corr(method="pearson")
        spear = df[nums].corr(method="spearman")
        pairs = []
        for i, a in enumerate(nums):
            for b in nums[i + 1:]:
                r = pear.loc[a, b]
                if pd.notna(r) and abs(r) >= cfg.corr_threshold:
                    pairs.append({"a": a, "b": b, "pearson": _r(r), "spearman": _r(spear.loc[a, b])})
        pairs.sort(key=lambda p: -abs(p["pearson"]))
        A.corr_pairs = pairs[: cfg.top_correlations]

    # Group differences: numeric metric across a categorical column's groups
    effects = []
    for c in cats:
        if not 2 <= df[c].nunique() <= 8:
            continue
        for n in nums:
            sub = df[[c, n]].dropna()
            groups = [g[n].values for _, g in sub.groupby(c) if len(g) >= 3]
            if len(groups) < 2:
                continue
            try:
                h, p = stats.kruskal(*groups)
            except ValueError:
                continue
            e2 = eta_squared(sub[c], sub[n])
            means = sub.groupby(c)[n].mean().sort_values()
            effects.append({"group": c, "metric": n, "p": _r(p, 5), "eta2": _r(e2),
                            "high": str(means.index[-1]), "high_mean": _r(means.iloc[-1]),
                            "low": str(means.index[0]), "low_mean": _r(means.iloc[0])})
    A.group_effects = sorted([e for e in effects if e["p"] is not None and e["p"] < 0.05],
                             key=lambda e: e["p"])[:10]

    # Categorical associations
    assoc = []
    for i, a in enumerate(cats):
        for b in cats[i + 1:]:
            if df[a].nunique() > 15 or df[b].nunique() > 15:
                continue
            v, p = cramers_v(df[a], df[b])
            if pd.notna(p) and p < 0.05 and v >= 0.2:
                assoc.append({"a": a, "b": b, "cramers_v": _r(v), "p": _r(p, 5)})
    A.cat_associations = sorted(assoc, key=lambda x: -x["cramers_v"])[:8]

    # Optional target-driven ranking
    if cfg.target and cfg.target in df.columns:
        A.target_ranking = _rank_against_target(df, schema, cfg.target)

    A.insights = _insights(res, A, cfg)
    return A


def _rank_against_target(df, schema, target):
    tk = schema.get(target)
    rows = []
    for c, k in schema.items():
        if c == target or k not in (NUMERIC, CATEGORICAL, BOOLEAN):
            continue
        score = None
        if tk == NUMERIC and k == NUMERIC:
            score = abs(df[c].corr(df[target]))
            how = "|Pearson r|"
        elif tk == NUMERIC and k != NUMERIC:
            score = np.sqrt(eta_squared(df[c], df[target]))
            how = "effect size (sqrt eta²)"
        elif tk != NUMERIC and k == NUMERIC:
            score = np.sqrt(eta_squared(df[target], df[c]))
            how = "effect size (sqrt eta²)"
        else:
            score, _ = cramers_v(df[c], df[target])
            how = "Cramér's V"
        if score is not None and pd.notna(score):
            rows.append({"feature": c, "score": _r(score), "measure": how})
    return sorted(rows, key=lambda r: -r["score"])[:12]


def _insights(res: CleanResult, A: Analysis, cfg: Config) -> list[dict]:
    """Each insight: {level: info|notable|warning, text}."""
    out = []

    def add(level, text):
        out.append({"level": level, "text": text})

    o = A.overview
    add("info", f"Dataset has {o['rows']:,} rows and {o['columns']} columns "
                f"({', '.join(f'{v} {k}' for k, v in o['kinds'].items())}).")
    if res.dropped_columns:
        add("warning", f"Dropped {len(res.dropped_columns)} mostly-empty column(s): "
                       f"{', '.join(res.dropped_columns)}.")
    worst = sorted(res.missing_before.items(), key=lambda kv: -kv[1])[:3]
    for c, n in worst:
        if n and c in res.df.columns:
            pct = 100 * n / max(res.rows_in, 1)
            add("warning" if pct > 20 else "info",
                f"'{c}' had {n} missing value(s) ({pct:.0f}%), handled by the cleaning rules.")
    if o["duplicates_removed"]:
        add("info", f"Removed {o['duplicates_removed']} duplicate row(s).")
    for c, od in sorted(res.outliers.items(), key=lambda kv: -kv[1]["count"])[:3]:
        add("notable", f"{od['count']} outlier(s) in '{c}' (outside {_fmt(od['lower'])} to "
                       f"{_fmt(od['upper'])}); flagged, not removed.")
    for c, p in A.numeric.items():
        gap = abs(p["mean"] - p["median"]) / abs(p["median"]) if p["median"] else 0
        if p["skew"] is not None and abs(p["skew"]) > 1 and gap > 0.03:
            side = "right" if p["skew"] > 0 else "left"
            add("info", f"'{c}' is {side}-skewed (skew {p['skew']:.1f}); median {_fmt(p['median'])} "
                        f"is more representative than mean {_fmt(p['mean'])}.")
    for c, p in A.categorical.items():
        if p["unique"] > 1 and p["dominant_pct"] and p["dominant_pct"] >= 75:
            add("notable", f"'{c}' is dominated by '{p['top'][0]['value']}' ({p['dominant_pct']:.0f}% of rows)"
                           " - groups are imbalanced.")
    for pr in A.corr_pairs[:4]:
        direction = "positively" if pr["pearson"] > 0 else "negatively"
        add("notable", f"'{pr['a']}' and '{pr['b']}' are {_strength(pr['pearson'])}ly {direction} "
                       f"correlated (r = {pr['pearson']:.2f}). Correlation is not causation.")
    for e in A.group_effects[:4]:
        add("notable", f"'{e['metric']}' differs across '{e['group']}' (p = {e['p']:.3g}): highest in "
                       f"'{e['high']}' (mean {_fmt(e['high_mean'])}), lowest in '{e['low']}' "
                       f"(mean {_fmt(e['low_mean'])}).")
    for a in A.cat_associations[:3]:
        add("notable", f"'{a['a']}' and '{a['b']}' are associated (Cramér's V = {a['cramers_v']:.2f}, "
                       f"p = {a['p']:.3g}).")
    sig = [t for t in A.trends if t["p"] is not None and t["p"] < 0.05 and t["pct_change"] is not None]
    for t in sorted(sig, key=lambda t: t["p"])[:4]:
        verb = "rose" if t["slope"] > 0 else "fell"
        add("notable", f"'{t['metric']}' {verb} about {abs(t['pct_change']):.0f}% over time by {t['period']} "
                       f"(trend p = {t['p']:.3g}).")
    if A.target_ranking:
        top = A.target_ranking[:3]
        add("notable", f"Strongest links to target '{cfg.target}': "
                       + ", ".join(f"'{r['feature']}' ({r['score']:.2f})" for r in top) + ".")
    if len(res.df) < 200:
        add("warning", f"Only {len(res.df)} rows: treat statistical results as indicative, not conclusive.")
    return out

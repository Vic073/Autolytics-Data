"""Command line interface: `autolytics run data.csv`."""
from __future__ import annotations

import subprocess
import sys
import webbrowser
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from . import __version__
from .config import Config
from .ingest import SUPPORTED, load_data
from .pipeline import run as run_pipeline

app = typer.Typer(add_completion=False, no_args_is_help=True,
                  help="Point it at data. Get a cleaned dataset, analysis and an interactive report.")
console = Console()


def _config(config, **kw) -> Config:
    try:
        return Config.load(config, **kw)
    except (ValueError, OSError, ImportError) as e:
        console.print(f"[red]Config error:[/red] {e}")
        raise typer.Exit(2)


@app.command("run")
def run_cmd(
    source: Path = typer.Argument(..., help="Data file: csv, tsv, xlsx, json, jsonl, parquet, sqlite, xml, html ..."),
    out: Path = typer.Option(Path("autolytics_output"), "--out", "-o", help="Output folder."),
    config: Optional[Path] = typer.Option(None, "--config", "-c", help="JSON or YAML settings file."),
    target: Optional[str] = typer.Option(None, "--target", "-t", help="Column to focus the analysis on."),
    title: Optional[str] = typer.Option(None, help="Report title."),
    sheet: Optional[str] = typer.Option(None, help="Excel sheet or SQLite table (name or position)."),
    anonymize: Optional[str] = typer.Option(None, help="none | hash | drop: handle personal-identifier columns."),
    outliers: Optional[str] = typer.Option(None, help="iqr | zscore | none."),
    clip_outliers: bool = typer.Option(False, "--clip-outliers", help="Clip outliers instead of only flagging."),
    no_report: bool = typer.Option(False, "--no-report", help="Skip the HTML report."),
    open_report: bool = typer.Option(False, "--open", help="Open the report in your browser when done."),
    dark: bool = typer.Option(False, "--dark", help="Open the report in dark mode."),
):
    """Run the full pipeline: load, clean, analyse, chart, report."""
    if sheet is not None and sheet.isdigit():
        sheet = int(sheet)  # type: ignore[assignment]
    cfg = _config(config, target=target, title=title, sheet=sheet, anonymize=anonymize,
                  outlier_method=outliers, clip_outliers=clip_outliers or None,
                  dark_mode_default=dark or None)
    with console.status("Running pipeline..."):
        try:
            res = run_pipeline(source, out, cfg, report=not no_report)
        except (FileNotFoundError, ValueError) as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(1)

    o = res.analysis.overview
    console.print(f"[bold green]Done.[/bold green] {o['rows_in']} rows in, {o['rows']} out, "
                  f"{o['columns']} columns, {len(res.charts)} charts.")
    for note in res.info.notes:
        console.print(f"[yellow]Note:[/yellow] {note}")
    if res.pii and cfg.anonymize == "none":
        console.print(f"[yellow]Privacy:[/yellow] possible personal identifiers in {list(res.pii)}. "
                      "Re-run with --anonymize hash (or drop) before sharing outputs.")
    console.print("\n[bold]Key insights[/bold]")
    icon = {"info": "[dim]·[/dim]", "notable": "[cyan]◆[/cyan]", "warning": "[yellow]![/yellow]"}
    for i in res.analysis.insights[:10]:
        console.print(f" {icon[i['level']]} {i['text']}")
    console.print("\n[bold]Files[/bold]")
    for k, p in res.outputs.items():
        console.print(f" {k:10} {p}")
    if open_report and "report" in res.outputs:
        webbrowser.open(res.outputs["report"].resolve().as_uri())


@app.command()
def profile(source: Path = typer.Argument(...), sheet: Optional[str] = typer.Option(None),
            config: Optional[Path] = typer.Option(None, "--config", "-c")):
    """Quick look: detected column types, missing values and outliers. Writes nothing."""
    from .analyze import analyze
    from .clean import clean
    cfg = _config(config, sheet=int(sheet) if sheet and sheet.isdigit() else sheet)
    try:
        raw, info = load_data(source, cfg.sheet)
    except (FileNotFoundError, ValueError) as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    res = clean(raw, cfg)
    an = analyze(res, cfg)
    console.print(f"[bold]{source.name}[/bold]  format: {info.fmt}"
                  + (f", encoding: {info.encoding}" if info.encoding else "")
                  + (f", delimiter: {info.delimiter!r}" if info.delimiter else ""))
    t = Table(show_lines=False)
    for h in ("column", "type", "missing (raw)", "outliers", "summary"):
        t.add_column(h)
    for c, k in res.schema.items():
        if c in an.numeric:
            p = an.numeric[c]
            summ = f"median {p['median']}, range {p['min']} to {p['max']}"
        elif c in an.categorical:
            top = an.categorical[c]["top"][0]
            summ = f"{an.categorical[c]['unique']} values, top '{top['value']}' ({top['pct']}%)"
        else:
            summ = ""
        t.add_row(c, k, str(res.missing_before.get(c, 0)), str(res.outliers.get(c, {}).get("count", 0)), summ)
    console.print(t)
    console.print(f"{res.rows_in} rows in, {res.rows_out} after cleaning. "
                  f"Use [bold]autolytics run {source}[/bold] for the full report.")


@app.command()
def dashboard(
    source: Optional[Path] = typer.Argument(None, help="Optional data file to preload."),
    port: int = typer.Option(8501, help="Port to serve on."),
):
    """Launch the interactive web dashboard (Streamlit)."""
    try:
        import streamlit  # noqa: F401
    except ImportError:
        console.print("[red]Streamlit is not installed.[/red] Run: pip install 'autolytics[dashboard]'")
        raise typer.Exit(1)
    script = Path(__file__).with_name("dashboard.py")
    cmd = [sys.executable, "-m", "streamlit", "run", str(script), "--server.port", str(port),
           "--browser.gatherUsageStats", "false"]
    if source:
        cmd += ["--", str(source.resolve())]
    raise typer.Exit(subprocess.call(cmd))


@app.command()
def demo(out: Path = typer.Option(Path("autolytics_demo"), "--out", "-o"),
         open_report: bool = typer.Option(False, "--open")):
    """Generate a messy synthetic 168-row health dataset and analyse it."""
    from .sample import make_messy_health_data
    out.mkdir(parents=True, exist_ok=True)
    raw = out / "sample_health_records.csv"
    make_messy_health_data().to_csv(raw, index=False)
    console.print(f"Wrote synthetic data to {raw}")
    res = run_pipeline(raw, out, Config(title="Sample health records"))
    console.print(f"[bold green]Done.[/bold green] Report: {res.outputs['report']}")
    if open_report:
        webbrowser.open(res.outputs["report"].resolve().as_uri())


@app.command()
def formats():
    """List supported input formats."""
    console.print("Supported: " + " ".join(SUPPORTED))
    console.print("Unknown extensions are tried as delimited text.")


@app.callback(invoke_without_command=True)
def _main(version: bool = typer.Option(False, "--version", "-v", is_eager=True)):
    if version:
        console.print(f"autolytics {__version__}")
        raise typer.Exit()


if __name__ == "__main__":
    app()
